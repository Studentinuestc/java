class Array {
    public static void main(String args[]) {
    int month_days [8];
    month_days [0] = 31;
    month_days [1] = 31;
    month_days [2] = 31;
    month_days [3] = 31;
    month_days [4] = 31;
    month_days [5] = 31;
    month_days [6] = 31;
    month_days [7] = 31;
    String str = "This is test";
    System.out.println("April has " + month_days[3] + " days ");
    System.out.println(str);
    }
}
