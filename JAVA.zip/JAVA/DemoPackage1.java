package p1;

public class Demo {
    public static void main(String args[]) {
        Protection ob1 = new Protection();
        Derived ob2 = new Derived();
        SamplePackage ob3 = new SamplePackage();
    }
}

