package p1;

class Derived extends Protection {
    Derived() {
        System.out.println("derived construtor");
        ....
    }

    System.out.println("n_pro = " + n_pro);
    .....
}