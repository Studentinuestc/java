class Box {
    double width;
    double height;
    double depth;

    Box(double w, double h, double d) {
        width = w;
        height = h;
        depth = d;
    }
    double volume() {
         return width * height * depth;
    }
}

class BoxWeight extends Box {
    double weight;

    BoxWeight(double w, double h, double d, double m) {
        width = w;
        height = h;
        depth = d;
        weight = m;
    }
}

class DemoWeight {
    public static void main(String args[]) {
        BoxWeight weightbox = new BoxWeigth(3,5,7,8.37);
        Box plainbox = new Box;
        plainbox = weightbox;
        ......
    }
}