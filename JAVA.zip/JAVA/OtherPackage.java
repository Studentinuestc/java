package p2;

class Otherpackage {
    Otherpackage() {
        p1.Protection p = new p1.Protection();
        System.out.println("Other package constructor");System.out.println("n.pro = " + p.n_pro);
        .....
    }
}