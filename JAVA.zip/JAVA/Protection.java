package p1;

public class Protection {
    int n = 1;
    private int_n_pri = 2;
    protected int n_pro = 3;
    public int_n_pub = 4;

    public Protection {
        System.out.println("base constructor");
        .....
    }
}