package p2;

class Protection2 extends p1.Protection {
    Protection2() {
        System.out.println("derived other package construtor");

        System.out.println("n.pro = " + p.n_pro);
        .....
    }
}