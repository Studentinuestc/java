package p1;

class SamplePackage {
    SamplePackage() {
        Protection p = new Protection();
        System.out.println("same package constructor");
        System.out.println("n = " + p.n);
        System.out.println("n.pro = " + p.n_pro);
        .....
    }
}