import MyPack.*;

class TestBalance {
    public static void main(String args[]) {
        Balance test = new Balance("J. J. Jaspers", 99.89);
        test.show();
    }
}